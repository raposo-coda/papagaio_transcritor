# Handoff: Papagaio Transcritor — tela única sem rolagem

## Visão geral
Redesenho da interface web do Papagaio Transcritor (`static/index.html` + `static/style.css` + `static/app.js`).
A tela atual empilha 8 blocos verticais com muito texto explicativo e exige rolagem longa para chegar ao botão
de iniciar. O redesenho condensa tudo em **uma tela de 1920×1080 sem rolagem**, com o botão de ação em barra
fixa no topo, campos reduzidos ao essencial e um **código de cor** que diz ao usuário onde ele precisa mexer e
o que sai (ou não) da máquina.

## Sobre os arquivos de design
Os arquivos deste pacote são **referências de design feitas em HTML** — protótipos que mostram aparência e
comportamento pretendidos, **não código de produção para copiar**. A tarefa é **recriar estes designs no
ambiente já existente do projeto**: HTML estático + CSS com variáveis + JS vanilla em IIFE, servido por FastAPI
a partir de `static/`. Não introduza framework, bundler ou dependência de front-end: o projeto roda numa
imagem Docker sem build step de JS, e a interface é servida direto do disco.

## Fidelidade
**Alta fidelidade (hifi).** Cores, tipografia, espaçamentos, estados e interações estão finais e vêm do
`style.css` atual (mesmas variáveis, mesma família monospace, mesmos raios de 2px). Recrie pixel a pixel,
reaproveitando as classes e variáveis CSS que já existem em vez de criar um sistema novo.

---

## Telas / vistas

### 1. `Papagaio Tela Unica.dc.html` — tela principal (a proposta)
**Objetivo:** o usuário escolhe o modo, joga arquivos e clica em Iniciar. Tudo visível de uma vez, sem rolagem.

**Layout** — coluna flex de altura fixa 1080px, largura 1920px, `overflow: hidden` no `html, body`:

| Faixa | Altura | Conteúdo |
|---|---|---|
| `header` | 76px fixos | logo, título, abas de modo, fila, estimativa, INICIAR, engrenagem, ajuda |
| `main` | `flex: 1; min-height: 0` | 3 colunas, `gap: 16px`, `padding: 16px 22px` |
| `footer` | 38px fixos | status + legenda do código de cor |

Colunas do `main`:
- **Esquerda — 400px fixos.** Dois cartões empilhados, `gap: 12px`: "1. Ajustes da transcrição" (altura natural)
  e "2. Sobre esta sessão (opcional)" (`flex: 1`, com o textarea de contexto crescendo até o fim da coluna).
- **Centro — `flex: 1`, `min-width: 0`.** Cartão "3. Arquivos" (`flex: 1`) com dropzone no topo e lista
  rolável abaixo; embaixo, cartão "4. Relatórios prontos" de altura natural.
- **Direita — 440px fixos.** Cartão de auditoria de privacidade (altura natural) e cartão "Log" (`flex: 1`,
  com a área de log rolável internamente).

Somente três áreas rolam internamente: lista de arquivos, log e (se necessário) o textarea. A página nunca rola.

**Componentes**

*Header*
- Logo `static/logo.png` 40×40, `filter: drop-shadow(0 0 7px rgba(57,242,216,0.35))`.
- Título: 16px, `#39f2d8`, uppercase, `letter-spacing: .06em`, `text-shadow: 0 0 8px rgba(57,242,216,.45)`,
  prefixo `> ` em `#ff4fd8`. Abaixo, versão em 11px `#4a6058`.
- **Abas de modo** — contêiner `border: 1px solid #24343d`, fundo `#0a0e12`. Cada aba: `padding: 9px 16px`,
  glifo 15px + rótulo 13px uppercase + subtítulo 10px minúsculo ("nada sai daqui" / "envia ao Google").
  - LOCAL ativa: fundo `rgba(77,255,158,.1)`, `box-shadow: inset 0 0 0 1px #4dff9e`, texto `#4dff9e`, glifo `◣` (`\u25A3`).
  - NUVEM ativa: fundo `rgba(255,201,77,.1)`, `inset 0 0 0 1px #ffc94d`, texto `#ffc94d`, glifo `△` (`\u25B3`).
  - Inativa: fundo transparente, texto `#4a6058`.
- **Fila** e **Tempo estimado**: pares rótulo (11px `#4a6058` uppercase `letter-spacing: .1em`) + valor (14px;
  fila em `#d3f4ee`, estimativa em `#39f2d8`), separados por divisor `1px × 44px` `#24343d`.
- **INICIAR**: `min-width: 210px; height: 52px`, 15px, peso 700, `letter-spacing: .1em`.
  - Habilitado: `background #39f2d8`, texto `#05100e`, `box-shadow: 0 0 18px -6px rgba(57,242,216,.8)`.
  - Desabilitado: `background #10161c`, borda `#24343d`, texto `#4a6058`, `cursor: not-allowed`.
  - Rodando: rótulo `PROCESSANDO...`, aparência de desabilitado.
- **Engrenagem** e **?**: quadrados 44×44, borda `#24343d`, fundo `#0a0e12`, ícone `#4a6058`;
  hover borda `#2c6e6a` e ícone `#39f2d8`.

*Cartões* — `border: 1px solid #24343d`, fundo `#131b22`, `border-radius: 2px`, `padding: 14px 16px`.
Título do cartão: 11px, peso 700, `#39f2d8`, uppercase, `letter-spacing: .12em`, prefixo `// ` em `#4a6058`,
`padding-bottom: 8px`, `border-bottom: 1px dashed #24343d`.

*Campos* — fundo `#0a0e12`, borda `1px solid #24343d`, **`border-left: 3px solid` colorida pelo código de cor**,
raio 2px, `padding: 10px`, 14px, família herdada. Rótulos: 11px `#7fa39a` uppercase `letter-spacing: .06em`.
Foco (comportamento atual do CSS): borda `#39f2d8` + `box-shadow: 0 0 0 1px #1f8f80`.

*Toggle "Separar falantes"* — substitui o checkbox atual. Trilho 54×26, raio 14px, `padding: 2px`;
ligado: borda `#39f2d8`, fundo `rgba(57,242,216,.15)`, botão alinhado à direita, esfera 20px `#39f2d8`;
desligado: borda `#24343d`, fundo `#0a0e12`, esfera `#4a6058` à esquerda.

*"Quantas pessoas falam"* — cinco botões `flex: 1`, `gap: 6px`, `padding: 9px 0`, 13px:
auto / 2 / 3 / 4 / 5+. Selecionado: borda `#39f2d8`, fundo `rgba(57,242,216,.1)`, texto `#39f2d8`.
Não selecionado: borda `#24343d`, fundo `#0a0e12`, texto `#7fa39a`. Só aparece com o toggle ligado.

*Dropzone* — `border: 2px dashed`, `padding: 26px 16px`, coluna centralizada com `gap: 14px`:
título 20px `#d3f4ee`, botão ciano cheio "+ Adicionar arquivos" (`#39f2d8` sobre `#05100e`, 13px, peso 700,
`padding: 12px 20px`), linha de formatos 11px `#4a6058`.
- Fila vazia (estado que pede ação): borda `#39f2d8`, fundo `rgba(57,242,216,.05)`.
- Fila com arquivos: borda `#24343d`, fundo `#0a0e12` — a dropzone recua visualmente.
- Arrastando por cima: mantenha o comportamento atual (`#dropzone.dragging`).

*Lista de arquivos* — `li` em flex, `gap: 14px`, `padding: 11px 14px`, separador `1px solid #131b22`:
nome (13px `#d3f4ee`, elipse), duração (12px `#7fa39a`, 88px à direita), tamanho (12px `#4a6058`, 80px à direita),
botão `×` (borda `#24343d`, texto `#4a6058`; hover borda e texto `#ff4fd8` — magenta = apaga coisas).
Vazia: linha "Nenhum arquivo na fila." 12px `#4a6058`.

*"Limpar fila"* — 11px uppercase; com arquivos: borda e texto `#ff4fd8`; sem arquivos: borda e texto `#24343d`, inerte.

*Relatórios prontos* — chips `<a>` em linha (`flex-wrap`, `gap: 8px`): borda `#2c6e6a`, fundo `#0a0e12`,
texto `#39f2d8`, 12px, `padding: 9px 12px`, seta `↓` `#4a6058` antes do nome; hover borda `#39f2d8`,
fundo `#131b22`. Cabeçalho do cartão mostra a pasta de destino em 11px `#4a6058`. Vazio: frase 12px `#4a6058`.
Com mais de um relatório, incluir o chip do `.zip` (rota `/api/jobs/<id>/download-all`).

*Auditoria de privacidade* — cartão colorido por modo, `padding: 14px 16px`, `gap: 8px`:
glifo 18px + título 13px, e uma linha de 12px `#7fa39a` `line-height: 1.55`.
- Local: borda e texto `#4dff9e`, fundo `rgba(77,255,158,.07)`,
  "Seu conteudo NAO sai deste computador".
- Nuvem: borda e texto `#ffc94d`, fundo `rgba(255,201,77,.07)`,
  "Seu conteudo SAI deste computador" + destino `generativelanguage.googleapis.com`.
Substitui o painel longo `#audit-panel` com listas "sai/fica"; o detalhamento completo vive no guia.

*Log* — área rolável, fundo `#0a0e12`, borda `#24343d`, `padding: 10px`, 12px, `line-height: 1.7`,
`white-space: pre-wrap`, prefixo `$ ` em `#4a6058` por linha. Cores por tag (iguais às atuais):
`ok #4dff9e`, `warn #ffc94d`, `err #ff5c7a`, `dim #4a6058`, padrão `#7fa39a`. Botão "Limpar" no cabeçalho.

*Footer* — status 12px `#39f2d8` com prefixo `> ` `#ff4fd8` à esquerda; à direita a **legenda do código de
cor**: cinco itens, quadrado 9×9 + rótulo 11px `#4a6058` uppercase `letter-spacing: .08em`, `gap: 18px`:
`#39f2d8` mexa aqui · `#4dff9e` fica na máquina · `#ffc94d` sai da máquina · `#4a6058` já configurado ·
`#ff4fd8` apaga coisas.

### 2. Modal de ajustes (engrenagem)
620px, fundo `#131b22`, borda `#2c6e6a`, `box-shadow: 0 0 40px -10px rgba(57,242,216,.35)`,
`padding: 22px 24px`, `gap: 18px`; fundo do overlay `rgba(5,8,11,.88)`, centralizado.
Contém **pasta de destino** (borda esquerda `#4a6058`) e **chave do Gemini** (borda esquerda `#ffc94d`,
com o link para `aistudio.google.com/apikey` e a nota "em branco mantém a chave atual").
Rodapé: "Cancelar" (fantasma) + "Salvar" (ciano cheio). Fechar por `×`, clique no overlay ou `Esc`.
No modo nuvem com chave já salva, a coluna esquerda mostra apenas a linha compacta
"Chave do Gemini **salva**" + botão "Trocar" (borda esquerda `#4dff9e`) — o campo de senha não ocupa a tela.

### 3. Modal de ajuda ("?")
720px, mesma moldura. Logo 64px + "> Três passos", lista ordenada 14px `line-height: 2` com os três passos
(escolher modo, arrastar arquivos, clicar em INICIAR), depois um parágrafo de 12px `#7fa39a` explicando o
código de cor. Botão "Entendi" ciano. Substitui o overlay `#guide-overlay` como *entrada* — o guia longo atual
(passos, "como funciona por dentro", FAQ) deve continuar acessível, por exemplo num link "ver guia completo"
dentro deste modal.

### 4. `Papagaio Atual.dc.html` — recriação da tela de hoje
Reprodução fiel da interface atual (modo local ativo), feita a partir de `index.html`/`style.css`.
Serve apenas como referência de comparação; não é alvo de implementação.

---

## Interações e comportamento
- **Trocar de modo** (abas do header): `POST /api/config {mode}`. Recolore as abas, troca o cartão de
  auditoria, mostra "Modelo local" (local) ou a linha da chave (nuvem), recalcula a estimativa e escreve no
  status. Se `local_available === false`, a aba LOCAL fica com `opacity: .55` e o clique explica como
  reconstruir a imagem, como hoje.
- **Toggle de falantes**: `POST /api/config {local_diarize}`; mostra/esconde os botões de quantidade e
  recalcula a estimativa. Indisponível (`diarization.available === false`): toggle inerte e aviso amarelo curto.
- **Quantidade de falantes**: `POST /api/config {local_num_speakers}` (0 = automático), recalcula estimativa.
- **Modelo local**: `POST /api/config {local_model}`, recalcula estimativa. Modelo ainda não baixado: acrescentar
  o aviso amarelo curto de download único (~MB) junto da estimativa no header, não um parágrafo.
- **Adicionar arquivos**: clique na dropzone ou no botão abre o `input[type=file]`; arrastar e soltar continua
  valendo. Filtrar por `supported_exts`, ler duração com `probeDuration`, atualizar fila e estimativa.
- **Remover / limpar fila**: mesma lógica atual; "Limpar fila" descarta tudo e zera os resultados.
- **INICIAR**: habilitado só com `files.length > 0` e, no modo nuvem, `has_api_key`. Enquanto faltar algo, o
  botão fica cinza e o **footer** diz o que falta (substitui o `#start-hint`). `POST /api/jobs` com
  `files`, `lang`, `title`, `context_prompt`; `setInterval` de 1500ms em `/api/jobs/{id}`; ao terminar,
  preencher os chips de relatórios e recarregar `/api/hardware`. Erro: linha vermelha no log + status.
- **Estimativa**: mesma fórmula de `hardware.estimate_seconds` já usada em `renderEstimate()`
  (transcrição = áudio/fator; preparo = áudio/25; com diarização multiplica 1.15 e soma áudio/speed_factor;
  +3s por arquivo). No modo nuvem, mostrar a estimativa de rede como hoje.
- **Transições**: 0.15s em `border-color` e `background` (padrão do CSS atual). Sem outras animações.
- **Responsivo**: alvo é 1920×1080. Abaixo de ~1500px de largura, a coluna direita (log + auditoria) pode
  colapsar para uma gaveta acionada por botão no header, preservando a regra de não rolar.

## Estado
Reaproveitar o objeto `state` de `app.js` — nada novo é necessário além de dois booleanos de UI:
`entries`, `langs`, `supportedExts`, `hasApiKey`, `mode`, `hardware`, `audit`, `localModelChoice`,
`localAvailable`, `diarize`, `numSpeakers`, `maxSpeakers`, `jobId`, `outputDir`, `defaultOutputDir`,
`polling`, `renderedLogCount`, mais `configOpen` e `guideOpen` para os dois modais.

## Design tokens
Todos já existem em `static/style.css` (`:root`) — não criar novos:

```
--bg #0a0e12   --bg-raised #10161c   --surface #131b22
--border #24343d   --border-bright #2c6e6a
--accent #39f2d8   --accent-dim #1f8f80   --accent2 #ff4fd8
--success #4dff9e   --warning #ffc94d   --error #ff5c7a
--text #d3f4ee   --subtext #7fa39a   --muted #4a6058
```

Semântica do código de cor (nova, e a razão de ser do redesenho):
`--accent` = você precisa mexer aqui agora · `--success` = fica na sua máquina ·
`--warning` = sai da sua máquina · `--muted` = já configurado, ignore ·
`--accent2` = apaga ou é irreversível.

Tipografia: `Consolas, "SFMono-Regular", "JetBrains Mono", monospace` em tudo.
Escala: 10 (tags), 11 (rótulos, legenda, notas), 12 (log, corpo secundário), 13 (corpo, itens de lista),
14 (valores de campo e do header), 15 (INICIAR), 16 (título do app), 20 (título da dropzone).
Espaçamento: 6 / 8 / 10 / 12 / 14 / 16 / 22 px. Raio: 2px em tudo (14px só no trilho do toggle).
Sombras: `0 1px 12px -4px rgba(57,242,216,.35)` (header), `0 0 18px -6px rgba(57,242,216,.8)` (INICIAR),
`0 0 40px -10px rgba(57,242,216,.35)` (modais), `0 0 7px rgba(57,242,216,.35)` (logo, via drop-shadow).

## Assets
- `assets/logo.png` — cópia de `static/logo.png` do repositório. Usar o arquivo original no lugar.
- Sem ícones novos: os glifos usados são caracteres (`◣ △ × ↓ ⚙ ? $ > //`), como no CSS atual.

## Arquivos
- `Papagaio Tela Unica.dc.html` — a proposta, interativa (troca de modo, fila, execução simulada, modais).
- `Papagaio Atual.dc.html` — recriação da tela atual, para comparação.
- `assets/logo.png` — logo usado pelos dois.

Fontes lidas no repositório: `static/index.html`, `static/style.css`, `static/app.js`, `README.md`.
